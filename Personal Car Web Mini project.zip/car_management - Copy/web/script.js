var allview= '<embed type="text/php" src="allview.php" width="1500" height="600">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = allview;


    var car=document.getElementById("car");
    var car_owner=document.getElementById("car_owner");
    var car_service=document.getElementById("car_service");
    var minor_checks=document.getElementById("minor_checks");
    var rc_card=document.getElementById("rc_card");
    //var result=document.getElementById("result");
    var all=document.getElementById("all");

function isselected() {
    
    
    
    if(all.checked==true){
        var allview= '<embed type="text/jsp" src="allview.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = allview;
       
       }
    
    
    
    else if(car.checked==true){
        var ca= '<embed type="text/jsp" src="car_reg_dis.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = ca;
        
        
    }
        else if(car_owner.checked==true){
            var car_owne= '<embed type="text/jsp" src="car_owner_reg_dis.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = car_owne;
            
        
            
    }
        else if(minor_checks.checked==true){
            var ae= '<embed type="text/jsp" src="minor_checks_display.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = ae;
          
            
        }
        else if(car_service.checked==true){
            var ce= '<embed type="text/jsp" src="car_service_reg_dis.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = ce;
            
            
          
            
        }
        else if(rc_card.checked==true){
            var cm= '<embed type="text/jsp" src="rc_card_display.jsp" width="1520" height="630">';
        //document.result.innerHTML = "The score you entered s: " + score + ". Your letter grade is: A!";
        document.getElementById('result').innerHTML = cm;
            
          
            
        }
    
    }
